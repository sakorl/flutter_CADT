class ItemModel {
  String image;
  ItemModel(this.image);
}